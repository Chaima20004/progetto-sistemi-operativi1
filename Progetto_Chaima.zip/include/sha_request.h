#ifndef _SHA_REQUEST_H
#define _SHA_REQUEST_H

#include <stdlib.h>
#include <stdio.h>

struct sha_request{
    long mtype;     //priorita' 
    int shm_ID;
    size_t shm_dim;
};

#endif
