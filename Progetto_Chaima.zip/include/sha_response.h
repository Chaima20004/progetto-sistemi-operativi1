#ifndef _SHA_RESPONSE_H
#define _SHA_RESPONSE_H

#include <stdio.h>
#include <stdlib.h>

#define MAX_DIGEST 65
struct sha_response{
    long mtype;     //priorita' 
    char digest[MAX_DIGEST];
};

#endif
