#ifndef IPC_H
#define IPC_H


//definizione dell'unione semun
union semun{
    int val; //valore per SETVAL setta il valore di un semaforo alla volta
    struct semid_ds *buf; //buffer per IPC_STAT e IPC_SET
    unsigned short *array; //vettore per GETALL e SETALL
};

void lock(int semid);

void unlock(int semid);

void close_sem(int semid);

void close_shm_ctrl(int shmid);

void close_queue(int msqid);

void close_shm(char *pt_shm, int shmid);

#endif
