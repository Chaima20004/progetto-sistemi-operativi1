/**
 * Introdurre un limite al numero di processi in esecuzione, modificabile dinamicamente da
un secondo client
 */
#include <stdio.h>
#include <stdlib.h>

//libererie per IPC
#include <sys/ipc.h>
#include <sys/stat.h>

//librerie per files
#include <fcntl.h>
#include <unistd.h>

//librerie per message queue
#include <sys/types.h>
#include <sys/msg.h>

//librerie per shared memory
#include <sys/shm.h>
#include "shared_mem.h"
//librerie per semafori
#include <sys/sem.h>

//librerie per stringhe 
#include <string.h>

//per control C uscita forzata
#include <signal.h>

//libreria nostra per gestire errori
#include "errExit.h"
#include "myipc.h"
#include "utils.h"

#define MAX_LIMIT 8
void handle_sigint(int);

int max_children;
int active_children;
int shmid_ctrl;
int semid;
int main(int argc, char *argv[]){
    
    //controllo numero argomenti esempio esecuzione: 
    if(argc != 2){
        errExit("Error: invalid number of arguments\n"); 
    }

    //key e get per shared memomy controller
    key_t shmkey = ftok("./keys/shm.key", atoi(argv[1]) % 255);
     if (shmkey == -1)
        errExit("ftok for shared memory failed\n");  
    shmid_ctrl = shmget(shmkey, sizeof(struct shared_mem),0); //ID del segmento condiviso per sharing num figli 
    if(shmid_ctrl == -1){
        errExit("Error: shmget failed\n");
    }

    //key e get per semaforo
    key_t semkey = ftok("./keys/sem.key", atoi(argv[1]) % 255);
     if (semkey == -1)
        errExit("ftok for semaphore failed\n");  
    semid = semget(semkey, 2, 0);
    if(semid == -1){
        close_shm_ctrl(shmid_ctrl);
        errExit("Error: semget failed\n");
    }
    
    //gestione ctrl C per chiudere shm e sem 
    signal(SIGINT, handle_sigint);

    //inizializzo shared memory per gestione figli  //ATTACH 1
    struct shared_mem *pt_shm_ctrl; 
    if((pt_shm_ctrl = (struct shared_mem *)shmat(shmid_ctrl, 0 ,0)) == (struct shared_mem *)-1){
        close_shm_ctrl(shmid_ctrl);
        close_sem(semid);
        errExit("Error: shmat 1 failed\n<server> closing\n");
    }
    
    //inizializzazione active e max children
    pt_shm_ctrl->active_children = 0;
    pt_shm_ctrl->max_children = 1;
   
    //detach mem
    if((shmdt(pt_shm_ctrl)) == -1){
        close_shm_ctrl(shmid_ctrl);
        close_sem(semid);
        errExit("Error: shmdt failed\n");
    }

    union semun arg; //istanzia l'unione semun(definita manualmente)
    arg.val = 1; //inizializza il semaforo 

    //inizializzo il semaforo
    if(semctl(semid, 0, SETVAL, arg) == -1){
        close_shm_ctrl(shmid_ctrl);
        close_sem(semid);
        errExit("Error: semctl failed\n<server> closing\n");
    }

    printf("<controller> ready\n");
    fflush(stdout);
   
    while(1){

        lock(semid);

        struct shared_mem *pt_shm_ctrl; 
        if((pt_shm_ctrl = (struct shared_mem *)shmat(shmid_ctrl, 0 ,0)) == (struct shared_mem *)-1){
            close_shm_ctrl(shmid_ctrl);
            close_sem(semid);
            errExit("Error: shmat failed\n");
        }
        //legge il valore active children in shm e lo salva
        active_children = pt_shm_ctrl->active_children;
        printf("<controller> updated active_children to: %d\n", active_children);
        
        //algoritmo per decidere il nuovo valore / se aggiornarlo  o meno
        if (active_children > 8)
            max_children = max(active_children - 1, 1);
        else if (active_children < 3)
            max_children = min(active_children + 1, MAX_LIMIT);
        // se active_children è tra 3 e 8 ---> non fara' nulla
        else
            max_children = pt_shm_ctrl->max_children;  // rimane invariato
         
        //carica su mem nuovo valore max children
        pt_shm_ctrl->max_children = max_children;
       
        printf("<controller> updated max_children to: %d\n\n", pt_shm_ctrl->max_children);
        
        //detach shared memory
        if((shmdt(pt_shm_ctrl)) == -1){
            close_shm_ctrl(shmid_ctrl);
            close_sem(semid);
            errExit("Error: shmdt failed\n");
        }

        //OPERAZIONE SEMAFORO sblocco
        unlock(semid);

        
        //SLEEP
        if (active_children == 0 && max_children == 1) {
                sleep(1);  // Aspetta più a lungo se il sistema è inattivo
            } else {
                sleep(0.1);  // Frequenza normale
        }
        
        
    }

    return 0;
    

}

//per gestire uscita forzata ctrl C
void handle_sigint(int sig){
    close_shm_ctrl(shmid_ctrl);
    close_sem(semid); 
    printf("\n<controller> closing\n");
    exit(0);
}
