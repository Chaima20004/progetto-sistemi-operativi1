#include <sys/sem.h>
#include <sys/ipc.h>
#include <sys/stat.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/msg.h>
#include <stddef.h>
#include "myipc.h"
#include "errExit.h"
#include "shared_mem.h"

void lock(int semid){
    struct sembuf sop = {.sem_num = 0, .sem_op = -1, .sem_flg = 0};

    if (semop(semid, &sop, 1) == -1){
        close_sem(semid);
        errExit("Error:lock failed\n");
    }
}

void unlock(int semid){
    struct sembuf sop = {.sem_num = 0, .sem_op = 1, .sem_flg = 0};

    if (semop(semid, &sop, 1) == -1){
        close_sem(semid);
        errExit("Error:lock failed\n");
    }
}

void close_sem(int semid){
    if(semctl(semid, 0, IPC_RMID) == -1)
        errExit("Error: semctl failed\n");
}

void close_shm_ctrl(int shmid){

    if((shmctl(shmid, IPC_RMID, 0)) == -1)
        errExit("Error: shmctl failed\n");
             
}


void close_queue(int msqid){

    if(msgctl(msqid, IPC_RMID, NULL) == -1)
        errExit("Error: msgctl failed\n");

}

void close_shm(char *pt_shm, int shmid){
    
    if((shmdt(pt_shm)) == -1)
        errExit("Error: shmdt failed\n");

    if((shmctl(shmid, IPC_RMID, 0)) == -1)
        errExit("Error: shmctl failed\n");
             
}