#include "errExit.h"

#include <stdlib.h>
#include <stdio.h>
#include <errno.h>

void errExit(const char *msg){
    perror(msg); //stampa il messaggio di errore ricevuto
    exit(1);
}