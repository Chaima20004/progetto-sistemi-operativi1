/**
 * Implementare server che riceve richieste ed invia risposte, usando code di messaggi
 */
#include <stdio.h>
#include <stdlib.h>

//librerie per message queue:
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/stat.h>

//librerie per shared memory
#include <sys/shm.h>

//libreria per figli
#include <unistd.h>
#include <signal.h>
#include "shared_mem.h"
//librerie per semafori
#include <sys/sem.h>

//librerie per funzione calculate_sha256
#include <openssl/sha.h>
#include <string.h>

//libreria nostra contenente struct dei messaggi di richiesta (filepath richiedenti impronte)
#include "sha_request.h"

//libreria nostra contenente struct dei messaggi di risposta (le impronte)
#include "sha_response.h"

//libreria nostra per gestire errori
#include "errExit.h"
#include "myipc.h"

void calculate_sha256(const char*, size_t, char*);



void handle_sigint(int);


int msqid = -1;
struct shared_mem *pt_shm_ctrl;
struct sha_request richiesta; //dove salviamo i messaggi ricevuti dal client:
struct sha_response risposta; 

int main(int argc, char *argv[]){

    //contrllo numero argomenti esempio esecuzione: ./server 103
    if(argc != 2)
        errExit("Error: invalid number of arguments, must be two\n"); 
        

    //dopo il comando ci sara un numero che sarà la key della coda di messaggi
    int msg_key = atoi(argv[1]);
    if(msg_key <= 0)
        errExit("Error: message queue key must be greater than zero\n");
        

    printf("<server> message queue ready with key\n");
    //inizializza coda di messaggi:
    msqid = msgget(msg_key, IPC_CREAT | S_IRUSR | S_IWUSR);
        if(msqid == -1){
            errExit("Error: creation queue failed\n");
        }

    //SHARED MEMORY PER CONTROLLER
    key_t shmkey = ftok("./keys/shm.key", msg_key % 255); //uso msg_key come val numerico per avercelo in comune con cotroller 
    if (shmkey == -1)
        errExit("ftok for shared memory failed\n");    
    int shmid_ctrl = shmget(shmkey, sizeof(struct shared_mem),IPC_CREAT|0666); //ID del segmento condiviso per sharing num figli con 2. client
    if(shmid_ctrl == -1){
        perror("shmget failed");
        close_queue(msqid);
        errExit("Error: shmget failed\n");
    }

    //SEMAFORO PER CONTROLLER
    key_t semkey = ftok("./keys/sem.key", msg_key % 255);
    if (semkey == -1)
        errExit("ftok for semaphore failed\n");   
    int semid = semget(semkey, 2, IPC_CREAT | 0666);
    if(semid == -1){
        close_queue(msqid);
        errExit("Error: semget failed\n");
    }
    
    // evita zombie: i figli verranno subito raccolti dal kernel
    signal(SIGCHLD, SIG_IGN);
    //gestione ctrl C per chiudere la queue 
    signal(SIGINT, handle_sigint);


    //prende il valore del semaforo dichiarato nel controller
    int sem_val = semctl(semid, 0, GETVAL);
    if (sem_val == -1) {
        close_queue(msqid);
        errExit("semctl failed");
    }

    while(1){
        //lettura coda messaggi:
        if(msgrcv(msqid, &richiesta, sizeof(struct sha_request)-sizeof(long), 0, 0 ) == -1){
            close_queue(msqid);
            errExit("Error: msgrcv failed\n<server> closing\n");
        }
        
        //blocco semaforo 
        lock(semid);
        //ATTACH 2
        if((pt_shm_ctrl = (struct shared_mem *)shmat(shmid_ctrl, 0 ,0)) == (struct shared_mem *)-1){
            close_queue(msqid);
            errExit("Error: shmat controller failed\n<server> closing\n");
        }
        
        // CONTROLLO LIMITE PROCESSI MASSIMO PRIMA DEL FORK
        if(pt_shm_ctrl->active_children >= pt_shm_ctrl->max_children) {
            printf("[PARENT %d] max limit of active processes reached (active=%d max=%d)\n", getpid(), pt_shm_ctrl->active_children, pt_shm_ctrl->max_children);
            
            // DETACH e sblocco semaforo
            if((shmdt(pt_shm_ctrl)) == -1) {
                close_queue(msqid);
                errExit("Error: shmdt controller failed\n");
            }
            unlock(semid);
            
            continue; // Ritorna all'inizio del loop
        }
        
        pt_shm_ctrl->active_children++;
        
        //stampa di debug
        //printf("[PARENT %d] Forking (active=%d max=%d)\n", getpid(), pt_shm_ctrl->active_children,  pt_shm_ctrl->max_children);
        
        //sblocco semaforo 
        unlock(semid);

        pid_t pid = fork();
        //errore:
        if(pid == -1){
            
            lock(semid);

            // Decrementa il contatore se il fork fallisce
            pt_shm_ctrl->active_children--;

            if((shmdt(pt_shm_ctrl)) == -1){
                close_queue(msqid);
                errExit("Error: shmdt controller failed\n");
            }

            errExit("Error: fork failed\n");

            unlock(semid);
          
        }

        //figlio:
        if(pid == 0){              
            //PER I CLIENT NORMALI  
            risposta.mtype = 1;
            //salvo dimensione segmento
            size_t shm_dim = richiesta.shm_dim;
            
            char *pt_shm; //puntatore a segmento condiviso
            if((pt_shm = (char *)shmat(richiesta.shm_ID, 0, 0)) == (char *)-1){
                close_queue(msqid);
                errExit("Error: shmat 4 failed\n");
            };
        
            printf("\n<server> calculating SHA digest...\n");
            
            //chiamo funzione calcolo SHA
            calculate_sha256(pt_shm, shm_dim, risposta.digest);
            
            //invia impronta calcolata:
            if(msgsnd(msqid, &risposta, sizeof(struct sha_response)-sizeof(long) , 0) == -1){
                close_queue(msqid);   
                errExit("Error: msgsnd failed\n");    
            }
            //detach char shm NORMALE
            if((shmdt(pt_shm)) == -1){
                close_queue(msqid);
                errExit("Error: shmdt failed\n");
            }
            printf("<server> SHA digest sent\n");
            
            //lock  3
            lock(semid); 
            
            pt_shm_ctrl->active_children--;
            //stampa di debug
            //printf("[CHILD %d] Terminated. Active now: %d\n\n", getpid(), pt_shm_ctrl->active_children);
            
            //unlock 3
            unlock(semid);
            
            exit(0);
        }
        //DETACH 
        if((shmdt(pt_shm_ctrl)) == -1){
            close_queue(msqid);
            errExit("Error: shmdt controller failed\n");
        }
       
    }
    
    return 0;
}

void calculate_sha256(const char *pt_shm, size_t shm_dim, char *output_digest){
    
    SHA256_CTX ctx;
    SHA256_Init(&ctx);

    SHA256_Update(&ctx, pt_shm, shm_dim );
    
    unsigned char hash[32];
    SHA256_Final(hash, &ctx);
    
    for(int i = 0; i < 32; i++)
        sprintf(output_digest + (i * 2), "%02x", hash[i]);
    
    output_digest[64] = '\0'; // Terminatore di stringa
}


//per gestire uscita forzata ctrl C
void handle_sigint(int sig){
    close_queue(msqid); 
    printf("\n<server> closing\n");
    exit(0);
}
