/**
 * Implementare client che invia richiesta e riceve risposta, usando code di messaggi
 */
#include <stdio.h>
#include <stdlib.h>

//libererie per IPC
#include <sys/ipc.h>
#include <sys/stat.h>

//librerie per files
#include <fcntl.h>
#include <unistd.h>

//librerie per message queue
#include <sys/types.h>
#include <sys/msg.h>

//librerie per shared memory
#include <sys/shm.h>

//librerie per stringhe 
#include <string.h>

//libreria nostra contenente struct dei messaggi di richiesta (filepath richiedenti impronte)
#include "sha_request.h"

//libreria nostra contenente struct dei messaggi di risposta (le impronte)
#include "sha_response.h"

//libreria nostra per gestire errori
#include "errExit.h"
#include "myipc.h"


#define MAX_READ 50

int msqid;
struct sha_request richiesta; 
struct sha_response risposta;
int main(int argc, char *argv[]){
    
    //controllo numero argomenti esempio esecuzione: ./client 103 (103 sarà il  message key)
    if(argc != 2){
        errExit("Error: invalid number of arguments, must be two\n"); 
    }

    //dopo il comando ci sara un numero che sarà la key della coda di messaggi
    int msg_key = atoi(argv[1]);
    if(msg_key <= 0){
        errExit("Error: message queue key must be greater than zero\n");
    }

    // Ottieni l'ID della coda di messaggi (deve già esistere perche' creata dal server)
    msqid = msgget(msg_key, 0); //non serve dare permessi perchè la coda esiste già con i suoi permessi e chiunque interagisce li eredita
    if (msqid == -1) {
        errExit("Error: msgget failed\n");
    }
  
    richiesta.mtype = 1; // inizializzo mtype
        
    //printf("insert file path:\n");
    
    char filepath[MAX_READ] ; //dove salvo il filepath digitato dall'user

    ssize_t numRead = read(STDIN_FILENO, filepath, MAX_READ);
    if(numRead == -1){
        errExit("Error: read from terminal failed\n");
    }
    filepath[numRead - 1] = '\0'; // il \n al posto len-1 lo sovrascrivo con \0
      
    //apre file in modalita solo lettura
    int fd = open (filepath, O_RDONLY);
     if(fd == -1){
        errExit("Error: file opening\n");
    }
        
    //ho aperto il file ora devo sapere la sua dim
    off_t file_sz = lseek(fd, 0, SEEK_END); //va alla fine del file
    if(file_sz == -1){
        errExit("Error: lseek failed\n");
    }
    if(lseek(fd, 0, SEEK_SET) == -1){ //ritorna all'inizio del file
        errExit("Error: lseek failed\n");
    } 
    
    //salvare file_sz nella sha request
    richiesta.shm_dim = file_sz;

    //creo segmento condiviso 
    int shmid = shmget(IPC_PRIVATE, file_sz, IPC_CREAT | S_IRUSR | S_IWUSR); //ID del segmento condiviso
    if(shmid == -1){
        errExit("Error: shmget failed\n");
    }
    
    //salvare shmid nella sha request richiesta
    richiesta.shm_ID = shmid;
    
    //creo puntatore a char che punta al segmento condiviso
    char *pt_shm; 
    if((pt_shm = (char *)shmat(shmid, 0 ,0)) == (char *)-1){
        close_shm(pt_shm, shmid);
        errExit("Error: shmat failed\n<client> closing\n");
    }
    
    //salva contenuto file nel buffer
    char *buffer = malloc(file_sz);
    if (buffer == NULL) {
        close_shm(pt_shm, shmid);
        errExit("Error: malloc failed\n");
    }
    if (read(fd, buffer, file_sz) == -1) {
        free(buffer);
        close_shm(pt_shm, shmid);
        errExit("Error: read failed\n");
    }
    //copia su memoria condivisa
    memcpy(pt_shm, buffer, file_sz);
    free(buffer);
    
    close(fd);

    printf("<client> sending message...\n");

    //manda messaggio al server
    if(msgsnd(msqid, &richiesta, sizeof(struct sha_request)-sizeof(long), 0) == -1){
        close_shm(pt_shm, shmid);
        errExit("Error: msgsnd failed\n");
    }
       
    //riceve impronta
    if(msgrcv(msqid, &risposta, sizeof(struct sha_response)-sizeof(long), 0, 0) == -1){
        close_shm(pt_shm, shmid);
        errExit("Error: msgrcv failed\n");;
    }

    printf("\nSHA digest: %s\n", risposta.digest);
        
    //DISLOCARE E ELIMINARE MEMORIA CONDIVISA
    close_shm(pt_shm, shmid);
            
    printf("\n<client> closing\n\n");

    return 0;

}
