#ifndef _ERREXIT_HH
#define _ERREXIT_HH

void errExit(const char *msg);

#endif
