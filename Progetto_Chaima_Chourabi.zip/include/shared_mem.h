#ifndef _SHARED_MEM_H
#define _SHARED_MEM_H

#include <stdlib.h>
#include <stdio.h>

struct shared_mem{
    int active_children;
    int max_children;
};

#endif
